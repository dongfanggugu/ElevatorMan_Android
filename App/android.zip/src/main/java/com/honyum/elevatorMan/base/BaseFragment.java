package com.honyum.elevatorMan.base;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.honyum.elevatorMan.activity.LoginActivity;
import com.honyum.elevatorMan.activity.property.PropertyMaintenanceActivity;
import com.honyum.elevatorMan.net.VersionCheckRequest;
import com.honyum.elevatorMan.net.base.NetConstant;
import com.honyum.elevatorMan.net.base.NetTask;
import com.honyum.elevatorMan.net.base.RequestBean;
import com.honyum.elevatorMan.net.base.RequestHead;
import com.honyum.elevatorMan.service.LocationService;
import com.honyum.elevatorMan.utils.RemindUtils;

public class BaseFragment extends Fragment implements PropertyMaintenanceActivity.IFilterLiftInfo {


    protected boolean mIsVisible = false;

    protected boolean mIsInitial = false;

    public int mFrom = 0;

//    /**
//     * 退出登录请求bean
//     * @return
//     */
//    private RequestBean getLogoutRequest() {
//        VersionCheckRequest request = new VersionCheckRequest();
//        RequestHead head = new RequestHead();
//
//        BaseFragmentActivity activity = (BaseFragmentActivity) getActivity();
//        head.setAccessToken(activity.getConfig().getToken());
//        head.setUserId(activity.getConfig().getUserId());
//
//        request.setHead(head);
//
//        return request;
//    }

    /**
     * 退出登录
     */
    protected void logout() {
        final Context context = getActivity();
        if (!(context instanceof BaseFragmentActivity)) {
            return;
        }
        final BaseFragmentActivity activity = (BaseFragmentActivity) getActivity();

        activity.logout();

//        NetTask netTask = new NetTask(activity.getConfig().getServer() + NetConstant.URL_LOG_OUT,
//                getLogoutRequest()) {
//            @Override
//            protected void onResponse(NetTask task, String result) {
//                activity.clearUserInfo();
//
//                //退出登录时，取消之前设置的闹钟
//                AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
//                for (PendingIntent pendingIntent : RemindUtils.mRemindList) {
//                    manager.cancel(pendingIntent);
//                }
//                //关闭定位服务
//                Intent sIntent = new Intent(getActivity(), LocationService.class);
//                getActivity().stopService(sIntent);
//
//                //启动
//                Intent intent = new Intent(getActivity(), LoginActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                startActivity(intent);
//                SysActivityManager.getInstance().exit();
//            }
//
//            @Override
//            protected void onFailed(NetTask task, String errorCode, String errorMsg) {
//                //super.onFailed(task, errorCode, errorMsg);
//                activity.clearUserInfo();
//                Intent intent = new Intent(getActivity(), LoginActivity.class);
//                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
//                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//                startActivity(intent);
//                SysActivityManager.getInstance().exit();
//            }
//        };
//        activity.addTask(netTask);

    }

    @Override
    public void onFilter(String project, String building, String unit, String liftNum) {

    }
}