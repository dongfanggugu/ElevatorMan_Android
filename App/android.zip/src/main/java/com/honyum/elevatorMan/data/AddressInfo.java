package com.honyum.elevatorMan.data;

/**
 * Created by changhaozhang on 16/6/22.
 */
public class AddressInfo {

    private String familyAddress = "";

    private String familyCity = "";

    private String familyCounty = "";

    private String familyProvince = "";



    private String residentAddress = "";

    private String residentCity = "";

    private String residentCounty = "";

    private String residentProvince = "";


    public String getFamilyAddress() {
        return familyAddress;
    }

    public void setFamilyAddress(String familyAddress) {
        this.familyAddress = familyAddress;
    }

    public String getFamilyCity() {
        return familyCity;
    }

    public void setFamilyCity(String familyCity) {
        this.familyCity = familyCity;
    }

    public String getFamilyCounty() {
        return familyCounty;
    }

    public void setFamilyCounty(String familyCounty) {
        this.familyCounty = familyCounty;
    }

    public String getFamilyProvince() {
        return familyProvince;
    }

    public void setFamilyProvince(String familyProvince) {
        this.familyProvince = familyProvince;
    }

    public String getResidentAddress() {
        return residentAddress;
    }

    public void setResidentAddress(String residentAddress) {
        this.residentAddress = residentAddress;
    }

    public String getResidentCity() {
        return residentCity;
    }

    public void setResidentCity(String residentCity) {
        this.residentCity = residentCity;
    }

    public String getResidentCounty() {
        return residentCounty;
    }

    public void setResidentCounty(String residentCounty) {
        this.residentCounty = residentCounty;
    }

    public String getResidentProvince() {
        return residentProvince;
    }

    public void setResidentProvince(String residentProvince) {
        this.residentProvince = residentProvince;
    }
}
