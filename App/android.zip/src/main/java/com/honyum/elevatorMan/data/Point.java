package com.honyum.elevatorMan.data;

/**
 * Created by chang on 2015/7/7.
 */
public class Point {
    private double lat;
    private double lng;

    public void setLat(double lat) {
        this.lat = lat;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public double getLat() {
        return lat;
    }

    public double getLng() {
        return lng;
    }
}
