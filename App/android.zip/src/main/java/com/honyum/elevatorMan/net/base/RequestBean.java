package com.honyum.elevatorMan.net.base;

public class RequestBean {
}