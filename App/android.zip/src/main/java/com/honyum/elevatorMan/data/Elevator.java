package com.honyum.elevatorMan.data;

import java.io.Serializable;

/**
 * 电梯数据
 * @author chang
 *
 */
public class Elevator implements Serializable {

	private String id = "0000";     //电梯id，用于报警

	private String unitCode = "1";     //单元号: unitCode + "单元"

	private String liftNum = "ABC1102";       //电梯唯一编号

	private String number = "001";     //自定义编号

	private String savedCount = "0";

	private String injureCount = "0";

	public String getSavedCount() {
		return savedCount;
	}

	public void setSavedCount(String savedCount) {
		this.savedCount = savedCount;
	}

	public String getInjureCount() {
		return injureCount;
	}

	public void setInjureCount(String injureCount) {
		this.injureCount = injureCount;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUnitCode() {
		return unitCode;
	}

	public void setUnitCode(String unitCode) {
		this.unitCode = unitCode;
	}

	public String getLiftNum() {
		return liftNum;
	}

	public void setLiftNum(String liftNum) {
		this.liftNum = liftNum;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
}