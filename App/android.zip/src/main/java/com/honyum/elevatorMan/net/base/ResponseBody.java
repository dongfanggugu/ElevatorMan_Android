package com.honyum.elevatorMan.net.base;

import java.io.Serializable;

public class ResponseBody implements Serializable {
}