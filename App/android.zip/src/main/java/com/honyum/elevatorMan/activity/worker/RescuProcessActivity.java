package com.honyum.elevatorMan.activity.worker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.baidu.navisdk.util.common.StringUtils;
import com.honyum.elevatorMan.R;
import com.jeremyfeinstein.slidingmenu.lib.SlidingMenu;

public class RescuProcessActivity extends WorkerBaseActivity {
	
	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rescu_process);

		Intent intent = getIntent();
		//获取此次报警事件的id
		String alarmId = intent.getStringExtra("alarm_id");
		initTitleBar();
		initView(alarmId);
	}
	
	/**
	 * 初始化view
	 */
	private void initView(String alarmId) {
		Button btnComplete = (Button) findViewById(R.id.btn_complete);
		btnComplete.setOnClickListener(buttonClickListener);
		btnComplete.setTag(alarmId);
	}
	
	/**
	 * 按钮点击事件
	 */
	private OnClickListener buttonClickListener = new OnClickListener() {

		@Override
		public void onClick(View view) {
			// TODO Auto-generated method stub
			switch (view.getId()) {
			case R.id.btn_complete:
				String alarmId = (String) view.getTag();
				alarmComplete(alarmId);
				break;
			}
		}
		
	};		
		
	/**
	 * 初始化标题栏
	 */
	private void initTitleBar() {
        initTitleBar(getString(R.string.title_rescu_process),
                R.id.title_rescu_process, R.drawable.back_normal,
                backClickListener);
//		String from = intent.getStringExtra("from");
//
//		if (StringUtils.isEmpty(from)) {
//			initTitleBar(getString(R.string.title_rescu_process),
//					R.id.title_rescu_process, R.drawable.navi_setting_normal,
//					menuClickListener);
//		} else if (from.equals(AlarmListActivity.TAG)) {
//			getSlidingMenu().setTouchModeAbove(SlidingMenu.TOUCHMODE_NONE);
//			setExitFlag(false);
//			initTitleBar(getString(R.string.title_rescu_process),
//					R.id.title_rescu_process, R.drawable.back_normal,
//					backClickListener);
//		}

	}
	
	/**
	 * 救援事件完成
	 */
	private void alarmComplete(final String alarmId) {
		
		Intent intent = new Intent(RescuProcessActivity.this, RescuSubmitActivity.class);
		intent.putExtra("alarm_id", alarmId);
		startActivity(intent);
	}
	
	
}