package com.honyum.elevatorMan.activity.worker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.baidu.navisdk.util.common.StringUtils;
import com.honyum.elevatorMan.R;
import com.honyum.elevatorMan.activity.common.MainpageActivity;
import com.honyum.elevatorMan.base.BaseFragmentActivity;
import com.honyum.elevatorMan.net.ReportStateRequest;
import com.honyum.elevatorMan.net.ReportStateRequest.ReportStateReqBody;
import com.honyum.elevatorMan.net.base.NetConstant;
import com.honyum.elevatorMan.net.base.NetTask;
import com.honyum.elevatorMan.net.base.RequestBean;
import com.honyum.elevatorMan.net.base.RequestHead;


public class RescuSubmitActivity extends BaseFragmentActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_rescu_submit);
		String alarmId = getIntent().getStringExtra("alarm_id");
		initTitleBar();
		initView(alarmId);
	}
	
	/**
	 * 初始化
	 */
	private void initView(final String alarmId) {
		final EditText etSaved = (EditText) findViewById(R.id.et_saved);
		final EditText etInjured = (EditText) findViewById(R.id.et_injured);
		final EditText etOther = (EditText) findViewById(R.id.et_other);
		Button btnSubmit = (Button) findViewById(R.id.btn_submit);
		
		btnSubmit.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
                if (StringUtils.isEmpty(etSaved.getText().toString())) {
                    showToast("请填写被救人数");
                    return;
                }

                if (StringUtils.isEmpty(etInjured.getText().toString())) {
                    showToast("请填写伤亡人数");
                    return;
                }
				int savedCount = parseFromString(etSaved.getText().toString());
				int injuredCount = parseFromString(etInjured.getText().toString());
				String other = etOther.getText().toString();
				submit(alarmId, savedCount, injuredCount, other);
			}
			
		});
	}
	
	/**
	 * 提交救援报表
	 * @param savedCount
	 * @param injuredCount
	 */
	private void submit(String alarmId, int savedCount, int injuredCount, String other) {
		//TODO  提交
		NetTask netTask = new NetTask(getConfig().getServer() + NetConstant.URL_REPORT_STATE, 
				getReportStateRequest(alarmId, savedCount, injuredCount, other)) {

					@Override
					protected void onResponse(NetTask task, String result) {
						// TODO Auto-generated method stub
						Toast.makeText(RescuSubmitActivity.this, getString(R.string.submit_suc), Toast.LENGTH_LONG)
						.show();
						Intent intent = new Intent(RescuSubmitActivity.this, MainpageActivity.class);
						intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					//	intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
						startActivity(intent);
					}

            @Override
            protected void onFailed(NetTask task, String errorCode, String errorMsg) {
                //super.onFailed(task, errorCode, errorMsg);
                showToast(errorMsg);

				Intent intent = new Intent(RescuSubmitActivity.this, MainpageActivity.class);
				intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				//	intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);

            }
        };
		
		addTask(netTask);
	}
	
	
	/**
	 * 初始化标题栏
	 */
	private void initTitleBar() {
		initTitleBar(getString(R.string.title_rescu_complete), R.id.title_rescu_complete, 
				R.drawable.back_normal, backClickListener);
	}
	
	/**
	 * 点击标题栏后退按钮事件
	 */
	private OnClickListener backClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			onBackPressed();
		}
		
	};
	
	
	/**
	 * 上报完成状态的请求
	 * @param alarmId
     * @param savedCount
     * @param injureCount
     * @param result
	 * @return
	 */
	private RequestBean getReportStateRequest(String alarmId, int savedCount, int injureCount,
			String result) {
		ReportStateRequest request = new ReportStateRequest();
		ReportStateReqBody body = request.new ReportStateReqBody();
		RequestHead head = new RequestHead();
		
		head.setUserId(getConfig().getUserId());
		head.setAccessToken(getConfig().getToken());
		
		body.setState("3");
		body.setAlarmId(alarmId);
		body.setInjureCount(injureCount);
		body.setSavedCount(savedCount);
		body.setResult(result);
		
		request.setHead(head);
		request.setBody(body);
		
		return request;		
	}
	
	/**
	 * 根据字符串返回int型
	 * @param string
	 * @return
	 */
	private int parseFromString(String string) {
		int result = 0;
		try {
			result = Integer.parseInt(string);
		} catch (Exception e) {
			result = 0;
		}
		return result;
	}
}