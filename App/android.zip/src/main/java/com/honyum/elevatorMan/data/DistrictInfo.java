package com.honyum.elevatorMan.data;

/**
 * Created by changhaozhang on 16/6/22.
 */
public class DistrictInfo extends Atom {

    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
