package com.honyum.elevatorMan.net.base;

import java.io.Serializable;

public class RequestBody implements Serializable {

}